#include<iostream>
#include<stdlib.h>
#include<math.h>
#include<cmath>
#include<iomanip>
#include<string>
#include"Map.h"
#include<vector>

int main()
{
	int input{};
	std::cout << "please enter a number as input :";
	std::cin >> input;
	std::cout << std::endl;
	Map map1{input};//object of class and you can put n in map1
	map1.showMap();//show random and show map of city
	std::cout << map1.findRoute() << std::endl;//for part(a) of problem show route 
	map1.showRout();
	std::cout << map1.findRout2() << std::endl;//for part(b) of problem show route 
	map1.showRout();
	map1.shortrout();//short rout for part(c)
	return 0;
}