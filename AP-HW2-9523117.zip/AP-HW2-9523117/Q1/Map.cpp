#include"Map.h"
#include<iostream>
#include<stdlib.h>
#include<iomanip>
#include<cmath>
#include<math.h>
#include<string>
#include<vector>
#include<bitset>
#include<random>

//costructor of class
Map::Map(int n){
std::cout << std::endl;	
std::cout << "Route that created by rand : " << std::endl;
N=n;
arr=new int*[N];//define two dimension array
for(int k{};k < N ;k++)
{
	arr[k]=new int[N];
}

for(int i{};i < N;i++)//giving value to 2D array
	for(int j{};j < N;j++)
	{
		arr[i][j]=rand() % 100;
	}
	
}

//function for showing map
void Map::showMap()//show map
{
	for(int i{};i < N;i++)
{
	for(int j{};j < N;j++)
	{
		std::cout <<std::setw(3) << arr[i][j];
	}
	std::cout << std::endl;
}
}



int Map::findRoute()//find route for part a of problem
{
	std::cout << std::endl;
	std::cout << "Part(A) :" << std::endl;
	int dist{};
	int i{},j{};
	arr1=new char*[N];//2D array for showing route with star
			for(int p{}; p < N;p++)
			{
				arr1[p]=new char[N];
			}
			for(int p{};p < N;p++)
			for(int v{};v < N;v++)
			{
				arr1[p][v]='-';
			}

			arr1[0][0]='*';
	while(i !=N-1 && j !=N-1)//this while compute dist and highlighting route
	{
	
			if(std::abs((arr[i][j] - arr[i+1][j])) <  std::abs((arr[i][j] - arr[i][j+1])))
			{
				
				dist += std::abs((arr[i][j] - arr[i+1][j]));
				
				i++;
				arr1[i][j]='*';
			
			}

			
			else
			{
				dist += std::abs((arr[i][j] - arr[i][j+1]));
				arr1[i][j+1]='*';
				j++;
			}	
	}

			if(i == N-1)
			{
			while (!(j==N-1))
			{
				dist += std::abs(arr[i][j+1] - arr[i][j]);
				j++;
				arr1[i][j]='*';				
			}

			}
			if(j == N-1)
			{
			while(!(i==N-1))
			{
				dist += std::abs(arr[i+1][j] - arr[i][j]);
				i++;
				arr1[i][j]='*';
			}
			}

			std::cout << "distance : ";
			
		return dist;
}

	

void Map::showRout()
{
	std::cout << std::endl;
	for(int i{};i < N;i++)
	{
		for(int j{};j < N;j++)
		{
			std::cout << std::setw(3) << arr1[i][j];
		}
		std::cout << std::endl;
	}
}



int Map::findRout2()//find route for part a of problem
{
	std::cout << "Part(B) :" << std::endl;
	int dist{};
	int i{},j{};
	arr1=new char*[N];//2D array for showing route with star
			for(int p{}; p < N;p++)
			{
				arr1[p]=new char[N];
			}
			for(int p{};p < N;p++)
			for(int v{};v < N;v++)
			{
				arr1[p][v]='-';
			}

			arr1[0][0]='*';
	while(i !=N-1 && j !=N-1)//this while compute dist and highlighting route
	{
		int a{std::abs(arr[i][j] - arr[i+1][j])};
		int b{std::abs(arr[i][j] - arr[i][j+1])};
		int c{std::abs(arr[i][j]- arr[i+1][j+1])};
	
			if((a < b && a < c)|| a==b)
			{
				dist += a;
				i++;
				arr1[i][j]='*';
			
			}
			if(b < a && b < c)
			{

				dist += b;
				arr1[i][j+1]='*';
				j++;

			}
			if((c < a && c < b)||a==c || b==c)
			{

				dist += c;
				arr1[i+1][j+1]='*';
				i++;
				j++;
			}
		}
			if(i == N-1)
			{
			while (!(j==N-1))
			{
				dist += std::abs(arr[i][j+1] - arr[i][j]);
				j++;
				arr1[i][j]='*';				
			}

			}
			if(j == N-1)
			{
			while(!(i==N-1))
			{
				dist += std::abs(arr[i+1][j] - arr[i][j]);
				i++;
				arr1[i][j]='*';
			}
			}
			std::cout << "distance : ";
		return dist;
}
void Map::shortrout()
{	
	std::vector<int> v;//for saving dist for each route
	std::cout << "PART (C) : " << std::endl;
	std::cout << "***Find best rout*** " << std::endl;
	int r{},d{};
	std::vector<std::string> rout{};
	for(int k{};k < std::pow(2,(2*N - 2)) ;k++)
	{
		int r1{},d1{};
 		r=r1;
 		d=d1;
		std::string binary=std::bitset<30>(k).to_string();//generate binary for each possible route
	   	binary = binary.substr(30-(2*N -2),30);
	for(int p{};p < (2*N - 2);p++)//this (for) is for compute dist
	{
 		
		if(binary[p]=='1')
			r++;
		else
			d++;
	}
	if(r==(N-1) && d==(N-1))
	{
		rout.push_back(binary);
		
	}
	}

	for(size_t k{};k < rout.size();k++)//show all possible route
	{

		std::cout <<"rout "<<k+1 <<" : 1 show right side and 0 show down side : "  << rout[k] <<std::endl;
		
	}
	std::cout << std::endl;

	for(size_t k{};k < rout.size();k++)
	{
	int dist{};
	int i{},j{};

	std::string ro{rout[k]};//ro is a string for moveing
	for(int p{};p < (2*N - 2);p++)
	{
		if(ro[p]=='1')
		{
			dist += std::abs(arr[i][j+1] - arr[i][j]);
			j++;
		}
		if(ro[p]=='0')
		{
			dist += std::abs(arr[i][j] - arr[i+1][j]);
			i++;
		}
	}	
	std::cout << "distance for rout " << k+1  << " : "<< dist << std::endl;
	v.push_back(dist);
	}

	for(size_t k{};k < v.size() ; k++)//sort distance for finding short route
	{
	for(size_t p{};p < v.size()-1 ; p++)
		{
			int temp{};
			if (v[p] > v[p+1])
			{
			temp = v[p+1];
			v[p+1] = v[p];
			v[p] = temp;
			}
		}
	}
	std::cout <<"====>>> short route distance is :  " << v[0] << std::endl;
}
