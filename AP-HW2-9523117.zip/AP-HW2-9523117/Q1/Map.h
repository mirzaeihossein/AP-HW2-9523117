#ifndef MAP_H
#define MAP_H
#include<iostream>
#include<vector>

class Map{
public:
Map(int n);//constructor
int N{};
int** arr{};//arr for rand route
char** arr1{};//arr1 for highlighting route
std::vector<std::string> rout;
void showMap();
int findRoute();
int findRout2();
void showRout();
void shortrout();


};
#endif