#include"libVec.h"
#include<iostream>
#include<vector>


long int libVec::counter(long int n)//define counter function
{
	long int temp{};//for doing zero variable
	N=n;
	std::vector<long int> v;
	sum=temp;
	for(long int i{};i < N;i++)
	{
		v.push_back(i);
		sum+=v[i];
	}
	return sum;
}
