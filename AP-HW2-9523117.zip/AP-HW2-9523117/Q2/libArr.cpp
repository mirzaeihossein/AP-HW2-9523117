#include"libArr.h"
#include<iostream>



long int libArr::counter(long int n)//define counter function
{
	long int temp{};//for doing zero variable
	N=n;
	int arr[N];//define array
	sum=temp;
	for(long int i{};i < N;i++)
	{
		arr[i]=i;
		sum+=arr[i];
	}
	return sum;
}

