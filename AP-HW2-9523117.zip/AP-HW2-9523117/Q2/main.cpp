#include<iostream>
#include<vector>
#include<ctime>
#include<ratio>
#include<chrono>
#include"libVec.h"
#include"libArr.h"

template <typename T1,typename T2> //define template
void runtime(T1 a,T2 ptfptr,int& n);//runtime function
int main()
{
libArr arr1;//object from libArr class
libVec vec1;//object from libVec class
long int (libArr::*ptfptr_Arr)(long int)=&libArr::counter;//define pointer to member
long int (libVec::*ptfptr_Vec)(long int)=&libVec::counter;//define pointer to member
int n{1};
while(n <= 1000000)//while for sum and show runtime for 1 to 1000000
{

	std::cout << "length of vector = " << n << std::endl;
	std::cout <<"sum : " << vec1.counter(n) << std::endl; 
	runtime(vec1,ptfptr_Vec,n);
	std::cout << std::endl;
	std::cout << "length of array = " << n << std::endl;
	std::cout <<"sum : " << arr1.counter(n) << std::endl;
	runtime(arr1,ptfptr_Arr,n);
	std::cout << std::endl; 
	n=n*10;
}


	return 0;

}
template <typename T1,typename T2> 
void runtime(T1 a,T2 ptfptr,int& n)
{
	using namespace std::chrono;
	auto t1 = high_resolution_clock::now();
	(a.*ptfptr)(n);
	auto t2 = high_resolution_clock::now();
	auto time_span = duration_cast<nanoseconds>(t2-t1);
	std::cout << "time of runnig : " << (time_span.count())/(1000000.0) << "   milliseconds" << std::endl; 
}





