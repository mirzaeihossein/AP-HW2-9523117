#ifndef LIBVEC_H
#define LIBVEC_H
#include<vector>

class libVec{
public:
libVec()=default;//default constructor
long int counter(long int);//counter function
std::vector<long int> v;
long int N;
long int sum{};
};
#endif