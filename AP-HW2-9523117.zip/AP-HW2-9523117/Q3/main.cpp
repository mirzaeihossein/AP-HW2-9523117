#include<iostream>
#include<string>
#include<fstream>
#include<vector>
#include<sstream>

template <typename T>
void disp(T v);
int main()
{
	std::ifstream is{"db.txt"};
	std::string s{};
	std::vector<std::string> v1;
	while(std::getline( is , s))
	{
    std::cout << s << std::endl;
		v1.push_back(s);
    }
    std::vector<std::string> ss1;
    std::vector<int> ss3;
    std::vector<int> ss4;
    std::string s1{},s2{};
    int s3{},s4{};
     std::vector<std::string> v;
    for(size_t i{};i < v1.size();i++)
    {
    	v.push_back(v1[i]);
    }
   
    for(size_t i{};i < v.size();i++)
    {
    	std::istringstream iss{v[i]};
    	iss >> s1 >> s2 >> s3 >> s4;
    	ss1.push_back(s1);
    	ss3.push_back(s3);
    	ss4.push_back(s4);
    }
    
   std::vector<int> barriers;
   barriers.push_back(0);
  for(size_t i{};i < ss1.size();i++)
   {
   		if(ss1[i+1].compare(ss1[i]))
   		{
   			barriers.push_back(i+1);
   		}		
   }
  std::vector<std::vector<int>> classify_p;
  std::vector<std::vector<int>> classify_c;
 	for(size_t j{};j < barriers.size()-1;j++)
 	{
  int a{barriers[j+1]-barriers[j]};
  int b{barriers[j+1]-barriers[j]};
  std::vector<int> row(a);
  std::vector<int> row2(b);
 	for(int i=barriers[j];i < barriers[j+1];i++)
 	{
    row[--a]=ss3[i];
    row2[--b]=ss4[i];
  }
  classify_p.push_back(row);
  classify_c.push_back(row2);
   		
 	}
 for(size_t i{};i < classify_p.size();i++)
  {
    for(size_t j{};j < classify_p[i].size()-1;j++)
    {
      int temp{};
      if (classify_p[i][j] > classify_p[i][j+1])
      {
      temp = classify_p[i][j+1];
      classify_p[i][j+1] = classify_p[i][j];
      classify_p[i][j] = temp;
    }
  }
}
for(size_t i{};i < classify_c.size();i++)
  {
    for(size_t j{};j < classify_c[i].size()-1;j++)
    {
      int temp{};
      if (classify_c[i][j] > classify_c[i][j+1])
      {
      temp = classify_c[i][j+1];
      classify_c[i][j+1] = classify_c[i][j];
      classify_c[i][j] = temp;
    }
  }
}
std::cout << std::endl;
std::ofstream out{"dbnew.txt"};
int cnt{};
int cnt1{};
 for(size_t i{};i < classify_p.size();i++)
  {
    int temp{1};
    cnt=temp;
    cnt1=temp;
    out << ss1[barriers[i]] << "] ";
    for(size_t j{};j < classify_p[i].size()-1;j++)
    {
      if(classify_p[i][j+1]!=(classify_p[i][j]))
      {
        cnt++;
      }
      if(classify_c[i][j+1]!=(classify_c[i][j]))
      {
        cnt1++;
      }
    }
    out << cnt << " " << cnt1 << std::endl;
  }
  
	return 0;

}
template <typename T>
void disp(T v)
{
	for(size_t i{};i < v.size();i++)
		std::cout << v[i] <<" ";
	std::cout << std::endl;
}
